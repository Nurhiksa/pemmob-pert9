package com.example.dashboard;

public class AboutMeController {
    // Tidak perlu method khusus
}
