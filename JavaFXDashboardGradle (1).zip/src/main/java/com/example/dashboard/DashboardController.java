package com.example.dashboard;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboardController {

    @FXML
    private void openAboutMe() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AboutMe.fxml"));
            Parent aboutMeRoot = fxmlLoader.load();
            Scene scene = new Scene(aboutMeRoot);
            Stage stage = new Stage();
            stage.setTitle("About Me");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
