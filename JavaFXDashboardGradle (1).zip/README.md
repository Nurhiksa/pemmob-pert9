# Latihan JavaFX Dashboard Gradle

Halo! Ini latihan project JavaFX Dashboard dengan Gradle. Aku nambahin halaman About Me biar beda sama repo aslinya.

## Cara Jalankan
1. Buka di IntelliJ IDEA atau VSCode.
2. Pastikan JDK 11+ dan JavaFX SDK sudah diatur di module-path.
3. Jalankan `MainApp`.

## Fitur Tambahan
- Tombol **Buka About Me**
- Halaman About Me menampilkan info singkat tentang saya.

## Dibuat oleh
Risma Nurhiksa
